import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from './register/register.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[RegisterService]
})
export class AppComponent {
  userName :string;
  Password :string;
  LoginForm:Boolean=true;
  constructor (private router:Router){

  }
  Validateuser(){

    if(this.userName=="Admin" && this.Password=="1234"){
   this.router.navigate(['/Register']);
   this.LoginForm=false;
    }
    else{
      alert("not valid");
    }
     
    
  }

}
