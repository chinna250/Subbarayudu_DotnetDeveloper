import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 registerForm:FormGroup;
 register:any=[];
  constructor(private _formBuilder:FormBuilder,private rvsc:RegisterService) { }

  ngOnInit(): void {
    this.registerForm=this._formBuilder.group({

      FirstName:['',Validators.required],
      LastName:['',Validators.required],
      Class:['',Validators.required],
      subject:['',Validators.required],
      marks:['',Validators.required],
      
      
    });
    this.getRegisterList();
  }
  Class=[
{id:'1',value:'X'},
{id:'2',value:'Xi'},
{id:'3',value:'Xii'}
  ];
  subject=[
    {id:'1',value:'English'},
    {id:'2',value:'Environmental'},
    {id:'3',value:'Social'}
  ];
  Register(){

this.rvsc.createRegister(this.registerForm.value).subscribe();
this.getRegisterList();
  }
  getRegisterList(){
    this.rvsc.getRegisterList().subscribe(x=>this.Register=x);
    console.log(this.Register);
  }

}
