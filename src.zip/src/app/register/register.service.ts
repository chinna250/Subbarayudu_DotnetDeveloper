import { Injectable } from '@angular/core';
import{HttpClient,HttpHeaders}from '@angular/common/http'; 
import {observable,Subject, Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch'; 
import { map } from 'rxjs/operators';
import { filter } from 'rxjs/operators';

import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RegisterService {
registerWebApi="https://localhost:44399/api/tblstudents";
  constructor(private _http:HttpClient) { }
  getRegisterList():Observable<any>{
    return this._http.get<any[]>(this.registerWebApi)
  }
  createRegister(regform:any):Observable<any>{
    const httpOptions={headers:new HttpHeaders({'content-Type':'appliction/json'})};
return this._http.post<any>(this.registerWebApi,regform,httpOptions)
  }
}
